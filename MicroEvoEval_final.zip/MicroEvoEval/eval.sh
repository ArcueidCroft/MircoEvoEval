python main.py --use_mode eval \
        --data_type den \
        --path_true work_dirs/PredRNN_den_300/saved/trues.npy \
        --path_pred work_dirs/PredRNN_den_300/saved/preds.npy \
        --save_results work_dirs/PredRNN_den_300/saved/