method = 'PhyDNet'
# model
patch_size = 4
# training
lr = 1e-3
batch_size = 16
sched = 'onecycle'