method = 'CrevNet'
n_eval = 18
rnn_size = 32
predictor_rnn_layers = 8
# training
lr = 5e-3
batch_size = 16
sched = 'onecycle'