optim_parameters = {
    'adam': {
        'weight_decay': 0,
    },
    'adamw': {
        'weight_decay': 0.01,
    },
    'sgd': {
        'momentum': 0,
        'dampening': 0,
        'weight_decay': 0,
        'nesterov': False,
    },
}